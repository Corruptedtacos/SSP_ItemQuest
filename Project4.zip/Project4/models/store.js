var mongoose = require('mongoose');

var storeSchema = mongoose.Schema({
    name: String,
    desc: String,
    address: [
    {
        city: String,
        state: String,
        zip: Number
    }],
    items: [{
        name: String,
        desc: String,
        price: Number,
        available: Boolean
    }]
});
storeSchema.index({name: 'text', desc: 'text'});

var Store = mongoose.model('Store', storeSchema);
module.exports = Store;
