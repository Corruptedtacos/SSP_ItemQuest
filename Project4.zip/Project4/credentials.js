let creds = {
    mongo: {
        connectionString: 'mongodb://clanter:password@ds249545.mlab.com:49545/cwl18_project3'
    }
};

module.exports = creds;
// JavaScript File